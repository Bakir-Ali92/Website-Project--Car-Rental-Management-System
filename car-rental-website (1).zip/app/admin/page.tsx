import { AdminDashboard } from "@/components/admin-dashboard"

export const metadata = {
  title: "Admin Dashboard - DriveNow Car Rentals",
  description: "Manage your car rental business with our comprehensive admin dashboard.",
}

export default function AdminPage() {
  return (
    <div className="min-h-screen py-8">
      <AdminDashboard />
    </div>
  )
}
