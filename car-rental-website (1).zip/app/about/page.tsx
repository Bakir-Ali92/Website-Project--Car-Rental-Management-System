import type { Metadata } from "next"
import { Button } from "@/components/ui/button"

export const metadata: Metadata = {
  title: "About | Car Rental",
  description: "Learn more about our car rental service in Sydney: our mission, values, and what makes us different.",
}

export default function AboutPage() {
  return (
    <main className="container mx-auto max-w-6xl px-4 py-10">
      <header className="mb-10">
        <h1 className="text-3xl md:text-4xl font-semibold text-pretty">About Our Car Rental Service</h1>
        <p className="mt-3 text-muted-foreground text-pretty">
          Reliable cars, transparent pricing, and friendly service—built for Sydney.
        </p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <article className="rounded-lg border bg-card text-card-foreground p-6">
          <h2 className="text-xl font-semibold text-pretty">Who We Are</h2>
          <p className="mt-3 text-muted-foreground leading-relaxed">
            We’re a locally-focused car rental team dedicated to making journeys across Sydney smooth and affordable.
            From quick city errands to weekend getaways, our fleet and service are designed around what you actually
            need—clarity, comfort, and convenience.
          </p>
        </article>

        <article className="rounded-lg border bg-card text-card-foreground p-6">
          <h2 className="text-xl font-semibold text-pretty">Our Mission</h2>
          <p className="mt-3 text-muted-foreground leading-relaxed">
            Keep mobility simple. We aim to deliver a seamless booking experience, well-maintained vehicles, and honest
            pricing—so you can spend less time planning and more time going.
          </p>
        </article>
      </section>

      <section className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-8">
        <article className="rounded-lg border bg-card text-card-foreground p-6">
          <h3 className="text-lg font-semibold">Why Choose Us</h3>
          <ul className="mt-3 list-disc pl-5 text-muted-foreground leading-relaxed">
            <li>Transparent, competitive pricing</li>
            <li>Flexible pickup/drop-off around Sydney</li>
            <li>Clean, regularly serviced vehicles</li>
            <li>Responsive support when you need it</li>
          </ul>
        </article>

        <article className="rounded-lg border bg-card text-card-foreground p-6">
          <h3 className="text-lg font-semibold">Sydney Coverage</h3>
          <p className="mt-3 text-muted-foreground leading-relaxed">
            We serve key areas across Sydney including CBD, Airport, Parramatta, North Sydney, and Bondi Beach. Choose
            the pickup point that fits your itinerary.
          </p>
        </article>

        <article className="rounded-lg border bg-card text-card-foreground p-6">
          <h3 className="text-lg font-semibold">Our Values</h3>
          <ul className="mt-3 list-disc pl-5 text-muted-foreground leading-relaxed">
            <li>Honesty in pricing and policies</li>
            <li>Reliability through maintenance and care</li>
            <li>Customer-first communication</li>
          </ul>
        </article>
      </section>

      <section className="mt-10 rounded-lg border bg-card text-card-foreground p-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h4 className="text-lg font-semibold">Ready to book?</h4>
            <p className="mt-1 text-muted-foreground">Explore our cars and secure your dates in minutes.</p>
          </div>
          <div className="flex gap-3">
            <Button asChild>
              <a href="/cars">View Cars</a>
            </Button>
            <Button variant="outline" asChild>
              <a href="/locations">Find a Location</a>
            </Button>
          </div>
        </div>
      </section>
    </main>
  )
}
