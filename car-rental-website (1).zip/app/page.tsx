import { HeroSection } from "@/components/hero-section"
import { SearchWidget } from "@/components/search-widget"
import { FeaturedCars } from "@/components/featured-cars"
import { Categories } from "@/components/categories"
import { HowItWorks } from "@/components/how-it-works"
import { SpecialOffers } from "@/components/special-offers"
import { Testimonials } from "@/components/testimonials"
import { TrustIndicators } from "@/components/trust-indicators"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <HeroSection />
      <SearchWidget />
      <FeaturedCars />
      <Categories />
      <HowItWorks />
      <SpecialOffers />
      <Testimonials />
      <TrustIndicators />
    </div>
  )
}
