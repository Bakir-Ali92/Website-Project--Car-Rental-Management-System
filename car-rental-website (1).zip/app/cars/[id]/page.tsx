import { notFound } from "next/navigation"
import { getCarById, getSimilarCars } from "@/lib/car-data"
import { CarDetailsView } from "@/components/car-details-view"

export default function CarDetailsPage({ params }: { params: { id: string } }) {
  const carId = Number.parseInt(params.id)
  const car = getCarById(carId)

  if (!car) {
    notFound()
  }

  const similarCars = getSimilarCars(car.id, car.category)

  return <CarDetailsView car={car} similarCars={similarCars} />
}
