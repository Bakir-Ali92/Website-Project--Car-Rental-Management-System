import { CarListings } from "@/components/car-listings"

export default function CarsPage() {
  return (
    <div className="min-h-screen py-8">
      <CarListings />
    </div>
  )
}
