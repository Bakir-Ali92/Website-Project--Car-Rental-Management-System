import { DealsView } from "@/components/deals-view"

export default function DealsPage() {
  return <DealsView />
}
