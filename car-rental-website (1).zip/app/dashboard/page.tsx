import { UserDashboard } from "@/components/user-dashboard"

export const metadata = {
  title: "My Dashboard - DriveNow Car Rentals",
  description: "View and manage your car rental bookings and account details.",
}

export default function DashboardPage() {
  return (
    <div className="min-h-screen py-8">
      <UserDashboard />
    </div>
  )
}
