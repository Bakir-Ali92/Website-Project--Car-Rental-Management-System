export interface Car {
  id: number
  name: string
  category: string
  image: string
  price: number
  rating: number
  reviews: number
  seats: number
  transmission: string
  luggage: number
  features: string[]
  badge?: string
  description?: string
  fuelType?: string
  year?: number
  mileage?: string
}

export const allCars: Car[] = [
  {
    id: 1,
    name: "Tesla Model 3",
    category: "Electric",
    image: "/tesla-model-3-sleek-profile.png",
    price: 89,
    rating: 4.9,
    reviews: 234,
    seats: 5,
    transmission: "Automatic",
    luggage: 2,
    features: ["GPS Navigation", "Bluetooth", "USB Charging", "Autopilot", "Premium Audio", "Climate Control"],
    badge: "Popular",
    description:
      "Experience the future of driving with the Tesla Model 3. This all-electric sedan combines cutting-edge technology with exceptional performance and zero emissions.",
    fuelType: "Electric",
    year: 2024,
    mileage: "Unlimited",
  },
  {
    id: 2,
    name: "BMW 5 Series",
    category: "Luxury",
    image: "/bmw-5-series.png",
    price: 129,
    rating: 4.8,
    reviews: 189,
    seats: 5,
    transmission: "Automatic",
    luggage: 3,
    features: ["GPS Navigation", "Leather Seats", "Sunroof", "Premium Sound", "Heated Seats", "Parking Sensors"],
    badge: "Premium",
    description:
      "The BMW 5 Series delivers the perfect blend of luxury, performance, and technology. Enjoy a sophisticated driving experience with premium comfort.",
    fuelType: "Gasoline",
    year: 2024,
    mileage: "200 miles/day",
  },
  {
    id: 3,
    name: "Toyota RAV4",
    category: "SUV",
    image: "/toyota-rav4-forest.png",
    price: 69,
    rating: 4.7,
    reviews: 312,
    seats: 5,
    transmission: "Automatic",
    luggage: 4,
    features: ["GPS Navigation", "Backup Camera", "AWD", "Bluetooth", "Cruise Control", "Lane Assist"],
    badge: "Best Value",
    description:
      "The Toyota RAV4 is perfect for family adventures and road trips. With spacious interior and all-wheel drive, it handles any terrain with ease.",
    fuelType: "Hybrid",
    year: 2024,
    mileage: "250 miles/day",
  },
  {
    id: 4,
    name: "Honda Civic",
    category: "Economy",
    image: "/honda-civic.jpg",
    price: 45,
    rating: 4.6,
    reviews: 428,
    seats: 5,
    transmission: "Automatic",
    luggage: 2,
    features: ["Bluetooth", "USB Charging", "Air Conditioning", "Backup Camera", "Cruise Control"],
    description:
      "The Honda Civic offers reliable and efficient transportation at an affordable price. Perfect for city driving and daily commutes.",
    fuelType: "Gasoline",
    year: 2023,
    mileage: "200 miles/day",
  },
  {
    id: 5,
    name: "Mercedes-Benz S-Class",
    category: "Luxury",
    image: "/luxurious-mercedes-s-class.png",
    price: 199,
    rating: 5.0,
    reviews: 156,
    seats: 5,
    transmission: "Automatic",
    luggage: 3,
    features: [
      "GPS Navigation",
      "Massage Seats",
      "Premium Sound System",
      "Panoramic Sunroof",
      "Ambient Lighting",
      "Advanced Safety",
    ],
    badge: "Luxury",
    description:
      "Experience ultimate luxury with the Mercedes-Benz S-Class. This flagship sedan offers unparalleled comfort, cutting-edge technology, and prestigious styling.",
    fuelType: "Gasoline",
    year: 2024,
    mileage: "150 miles/day",
  },
  {
    id: 6,
    name: "Ford Transit Van",
    category: "Van",
    image: "/ford-transit-van.png",
    price: 95,
    rating: 4.5,
    reviews: 203,
    seats: 12,
    transmission: "Automatic",
    luggage: 8,
    features: ["GPS Navigation", "Backup Camera", "Cruise Control", "Bluetooth", "Power Windows", "AC"],
    description:
      "The Ford Transit Van is ideal for group travel and cargo transport. Spacious interior with seating for up to 12 passengers.",
    fuelType: "Diesel",
    year: 2023,
    mileage: "200 miles/day",
  },
]

export function getCarById(id: number): Car | undefined {
  return allCars.find((car) => car.id === id)
}

export function getSimilarCars(carId: number, category: string, limit = 3): Car[] {
  return allCars.filter((car) => car.id !== carId && car.category === category).slice(0, limit)
}
