"use client"

import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Car, CreditCard, User, Star } from "lucide-react"

const upcomingBookings = [
  {
    id: 1,
    car: "Tesla Model 3",
    image: "/tesla-model-3.png",
    pickup: "2024-02-15",
    dropoff: "2024-02-20",
    location: "Sydney Airport",
    total: 445,
    status: "Confirmed",
  },
]

const pastBookings = [
  {
    id: 2,
    car: "BMW 5 Series",
    image: "/bmw-5-series.png",
    pickup: "2024-01-10",
    dropoff: "2024-01-15",
    location: "Sydney CBD",
    total: 645,
    status: "Completed",
  },
  {
    id: 3,
    car: "Toyota RAV4",
    image: "/toyota-rav4.png",
    pickup: "2023-12-20",
    dropoff: "2023-12-27",
    location: "Bondi Beach",
    total: 483,
    status: "Completed",
  },
]

export function UserDashboard() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl lg:text-4xl font-bold mb-2">My Dashboard</h1>
        <p className="text-muted-foreground">Manage your bookings and account</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Active Bookings</p>
                <p className="text-3xl font-bold">1</p>
              </div>
              <Car className="h-10 w-10 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total Trips</p>
                <p className="text-3xl font-bold">12</p>
              </div>
              <Calendar className="h-10 w-10 text-accent" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Loyalty Points</p>
                <p className="text-3xl font-bold">2,450</p>
              </div>
              <Star className="h-10 w-10 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total Spent</p>
                <p className="text-3xl font-bold">$3.2K</p>
              </div>
              <CreditCard className="h-10 w-10 text-green-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="upcoming" className="space-y-6">
        <TabsList>
          <TabsTrigger value="upcoming">Upcoming Bookings</TabsTrigger>
          <TabsTrigger value="past">Past Bookings</TabsTrigger>
          <TabsTrigger value="profile">Profile</TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming" className="space-y-4">
          {upcomingBookings.map((booking) => (
            <Card key={booking.id}>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-6">
                  <img
                    src={booking.image || "/placeholder.svg"}
                    alt={booking.car}
                    className="w-full md:w-48 h-32 object-cover rounded-lg"
                  />

                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-bold mb-1">{booking.car}</h3>
                        <p className="text-sm text-muted-foreground">Booking #{booking.id}</p>
                      </div>
                      <Badge className="bg-accent text-accent-foreground">{booking.status}</Badge>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm font-medium">Pickup</p>
                          <p className="text-sm text-muted-foreground">{booking.pickup}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm font-medium">Dropoff</p>
                          <p className="text-sm text-muted-foreground">{booking.dropoff}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Car className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm font-medium">Location</p>
                          <p className="text-sm text-muted-foreground">{booking.location}</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-2xl font-bold text-primary">${booking.total}</span>
                        <span className="text-sm text-muted-foreground ml-1">total</span>
                      </div>

                      <div className="flex gap-2">
                        <Button variant="outline">Modify</Button>
                        <Button variant="outline" className="text-destructive bg-transparent">
                          Cancel
                        </Button>
                        <Button className="bg-primary hover:bg-primary/90">View Details</Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="past" className="space-y-4">
          {pastBookings.map((booking) => (
            <Card key={booking.id}>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-6">
                  <img
                    src={booking.image || "/placeholder.svg"}
                    alt={booking.car}
                    className="w-full md:w-48 h-32 object-cover rounded-lg"
                  />

                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-bold mb-1">{booking.car}</h3>
                        <p className="text-sm text-muted-foreground">Booking #{booking.id}</p>
                      </div>
                      <Badge variant="secondary">{booking.status}</Badge>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm font-medium">Pickup</p>
                          <p className="text-sm text-muted-foreground">{booking.pickup}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm font-medium">Dropoff</p>
                          <p className="text-sm text-muted-foreground">{booking.dropoff}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Car className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm font-medium">Location</p>
                          <p className="text-sm text-muted-foreground">{booking.location}</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-2xl font-bold">${booking.total}</span>
                        <span className="text-sm text-muted-foreground ml-1">total</span>
                      </div>

                      <div className="flex gap-2">
                        <Button variant="outline">View Receipt</Button>
                        <Button className="bg-primary hover:bg-primary/90">Book Again</Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center gap-6">
                <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center">
                  <User className="h-12 w-12 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-1">John Doe</h3>
                  <p className="text-muted-foreground">john.doe@example.com</p>
                  <Button variant="outline" size="sm" className="mt-2 bg-transparent">
                    Edit Profile
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label className="text-sm font-medium mb-2 block">Phone Number</Label>
                  <p className="text-muted-foreground">+1 (555) 123-4567</p>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">Driver's License</Label>
                  <p className="text-muted-foreground">DL123456789</p>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">Member Since</Label>
                  <p className="text-muted-foreground">January 2023</p>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">Loyalty Tier</Label>
                  <Badge className="bg-accent text-accent-foreground">Gold Member</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
