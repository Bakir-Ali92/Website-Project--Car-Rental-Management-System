"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Percent, Calendar, Briefcase } from "lucide-react"

const offers = [
  {
    icon: Percent,
    title: "20% Off Weekend Rentals",
    description: "Book any car for the weekend and save 20% on your total",
    code: "WEEKEND20",
    color: "bg-blue-500",
  },
  {
    icon: Calendar,
    title: "Long-Term Discounts",
    description: "Rent for 7+ days and get up to 30% off",
    code: "LONGTERM30",
    color: "bg-green-500",
  },
  {
    icon: Briefcase,
    title: "Corporate Packages",
    description: "Special rates for business travelers and companies",
    code: "CORPORATE",
    color: "bg-purple-500",
  },
]

export function SpecialOffers() {
  return (
    <section className="py-16 lg:py-24 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">Special Offers</h2>
          <p className="text-lg text-muted-foreground">Save more with our exclusive deals and promotions</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {offers.map((offer) => {
            const Icon = offer.icon
            return (
              <Card key={offer.title} className="overflow-hidden">
                <div className={`${offer.color} p-6 text-white`}>
                  <Icon className="h-12 w-12 mb-4" />
                  <h3 className="text-xl font-bold mb-2">{offer.title}</h3>
                </div>
                <CardContent className="p-6">
                  <p className="text-muted-foreground mb-4">{offer.description}</p>
                  <div className="flex items-center justify-between">
                    <Badge variant="outline" className="font-mono">
                      {offer.code}
                    </Badge>
                    <Button variant="link" className="text-primary">
                      Learn More
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
