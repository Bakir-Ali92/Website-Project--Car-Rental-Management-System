"use client"

import { Button } from "@/components/ui/button"
import { Car, Shield, Clock, Award } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative bg-gradient-to-br from-slate-900 to-slate-800 text-white overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-[url('/luxury-cars-on-road.png')] bg-cover bg-center" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
        <div className="max-w-3xl">
          <h1 className="text-5xl lg:text-6xl font-bold mb-6 text-balance">Your Journey Starts Here</h1>
          <p className="text-xl lg:text-2xl text-slate-300 mb-8 text-pretty">
            Premium car rentals with 24/7 support, best price guarantee, and free cancellation
          </p>
          <div className="flex flex-wrap gap-4 mb-12">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-white">
              Book Now
            </Button>
            <Button size="lg" variant="outline" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
              View Fleet
            </Button>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="flex items-center gap-3">
              <Car className="h-8 w-8 text-accent" />
              <div>
                <div className="text-2xl font-bold">500+</div>
                <div className="text-sm text-slate-300">Cars Available</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-accent" />
              <div>
                <div className="text-2xl font-bold">10K+</div>
                <div className="text-sm text-slate-300">Happy Customers</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Clock className="h-8 w-8 text-accent" />
              <div>
                <div className="text-2xl font-bold">24/7</div>
                <div className="text-sm text-slate-300">Support</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Award className="h-8 w-8 text-accent" />
              <div>
                <div className="text-2xl font-bold">50+</div>
                <div className="text-sm text-slate-300">Locations</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
