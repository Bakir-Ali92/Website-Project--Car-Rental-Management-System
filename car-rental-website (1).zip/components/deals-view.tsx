"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Calendar, Clock, Tag, TrendingDown, Car, Users, Briefcase, Sun, Gift } from "lucide-react"
import Link from "next/link"

const deals = [
  {
    id: 1,
    title: "Summer Special",
    description: "Book any car for 7+ days and save big on your summer adventure",
    discount: "30%",
    category: "seasonal",
    validUntil: "2024-03-31",
    terms: "Valid for bookings of 7 days or more. Cannot be combined with other offers.",
    image: "🌞",
    code: "SUMMER30",
    featured: true,
  },
  {
    id: 2,
    title: "Weekend Warrior",
    description: "Special rates for weekend rentals - Friday to Monday",
    discount: "20%",
    category: "weekend",
    validUntil: "2024-12-31",
    terms: "Valid for Friday-Monday bookings only. Subject to availability.",
    image: "🎉",
    code: "WEEKEND20",
    featured: true,
  },
  {
    id: 3,
    title: "Long Term Saver",
    description: "Rent for 30+ days and enjoy massive savings",
    discount: "40%",
    category: "long-term",
    validUntil: "2024-12-31",
    terms: "Valid for rentals of 30 days or more. Advance booking required.",
    image: "📅",
    code: "LONGTERM40",
    featured: true,
  },
  {
    id: 4,
    title: "Corporate Package",
    description: "Special rates for business travelers and corporate accounts",
    discount: "25%",
    category: "corporate",
    validUntil: "2024-12-31",
    terms: "Valid for corporate bookings. Company verification required.",
    image: "💼",
    code: "CORP25",
    featured: false,
  },
  {
    id: 5,
    title: "Early Bird Special",
    description: "Book 30 days in advance and save",
    discount: "15%",
    category: "advance",
    validUntil: "2024-12-31",
    terms: "Must book at least 30 days before pickup date.",
    image: "🐦",
    code: "EARLY15",
    featured: false,
  },
  {
    id: 6,
    title: "Electric Vehicle Promo",
    description: "Go green and save on all electric vehicles",
    discount: "20%",
    category: "eco",
    validUntil: "2024-12-31",
    terms: "Valid for electric vehicles only. Subject to availability.",
    image: "⚡",
    code: "GREEN20",
    featured: false,
  },
  {
    id: 7,
    title: "Luxury Experience",
    description: "Premium cars at special rates for 3+ days",
    discount: "18%",
    category: "luxury",
    validUntil: "2024-06-30",
    terms: "Valid for luxury category vehicles. Minimum 3-day rental.",
    image: "✨",
    code: "LUX18",
    featured: false,
  },
  {
    id: 8,
    title: "Family Package",
    description: "SUVs and vans with free child seats",
    discount: "22%",
    category: "family",
    validUntil: "2024-12-31",
    terms: "Includes 2 free child seats. Valid for SUVs and vans.",
    image: "👨‍👩‍👧‍👦",
    code: "FAMILY22",
    featured: false,
  },
]

const categories = [
  { id: "all", label: "All Deals", icon: Gift },
  { id: "seasonal", label: "Seasonal", icon: Sun },
  { id: "weekend", label: "Weekend", icon: Calendar },
  { id: "long-term", label: "Long Term", icon: Clock },
  { id: "corporate", label: "Corporate", icon: Briefcase },
  { id: "family", label: "Family", icon: Users },
]

export function DealsView() {
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")

  const filteredDeals = deals.filter((deal) => {
    const matchesCategory = selectedCategory === "all" || deal.category === selectedCategory
    const matchesSearch =
      deal.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      deal.description.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const featuredDeals = filteredDeals.filter((deal) => deal.featured)
  const regularDeals = filteredDeals.filter((deal) => !deal.featured)

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-accent/10 py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Badge className="mb-4 bg-accent text-accent-foreground">Limited Time Offers</Badge>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-balance">Exclusive Deals & Offers</h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 text-pretty">
            Save big on your next car rental with our special promotions and discount codes
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <div className="flex items-center gap-2 text-sm">
              <TrendingDown className="h-5 w-5 text-accent" />
              <span className="font-semibold">Up to 40% Off</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Tag className="h-5 w-5 text-accent" />
              <span className="font-semibold">Promo Codes Available</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Gift className="h-5 w-5 text-accent" />
              <span className="font-semibold">Free Add-ons</span>
            </div>
          </div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="py-8 border-b bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="w-full md:w-96">
              <Input
                type="text"
                placeholder="Search deals..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full"
              />
            </div>
            <div className="flex flex-wrap gap-2 justify-center">
              {categories.map((category) => {
                const Icon = category.icon
                return (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category.id)}
                    className="gap-2"
                  >
                    <Icon className="h-4 w-4" />
                    {category.label}
                  </Button>
                )
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Deals */}
      {featuredDeals.length > 0 && (
        <section className="py-12 md:py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold mb-2">Hot Deals</h2>
                <p className="text-muted-foreground">Don't miss out on these limited-time offers</p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-stretch">
              {featuredDeals.map((deal) => (
                <Card
                  key={deal.id}
                  className="relative overflow-hidden border-2 border-accent/50 hover:border-accent transition-all hover:shadow-lg flex flex-col h-full min-h-64"
                >
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-accent text-accent-foreground text-lg font-bold px-3 py-1">
                      {deal.discount} OFF
                    </Badge>
                  </div>
                  <CardHeader className="pt-6">
                    <div className="text-5xl mb-4">{deal.image}</div>
                    <CardTitle className="text-2xl">{deal.title}</CardTitle>
                    <CardDescription className="text-base">{deal.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-grow space-y-4">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span>Valid until {new Date(deal.validUntil).toLocaleDateString()}</span>
                    </div>
                    <div className="bg-muted p-3 rounded-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Promo Code:</span>
                        <code className="bg-background px-3 py-1 rounded font-mono font-bold text-primary">
                          {deal.code}
                        </code>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground">{deal.terms}</p>
                  </CardContent>
                  <CardFooter className="mt-auto p-6">
                    <Button asChild className="w-full bg-accent hover:bg-accent/90">
                      <Link href="/cars">Book Now</Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Regular Deals */}
      {regularDeals.length > 0 && (
        <section className="py-12 md:py-16 bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-8">
              <h2 className="text-3xl font-bold mb-2">More Great Deals</h2>
              <p className="text-muted-foreground">Additional savings for every occasion</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-stretch">
              {regularDeals.map((deal) => (
                <Card
                  key={deal.id}
                  className="hover:shadow-lg transition-all flex flex-col h-full min-h-64 overflow-hidden"
                >
                  <CardHeader className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="text-4xl">{deal.image}</div>
                      <Badge variant="secondary" className="text-base font-bold">
                        {deal.discount} OFF
                      </Badge>
                    </div>
                    <CardTitle className="text-xl mt-4">{deal.title}</CardTitle>
                    <CardDescription>{deal.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-grow space-y-3">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span>Valid until {new Date(deal.validUntil).toLocaleDateString()}</span>
                    </div>
                    <div className="bg-muted p-2 rounded">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-medium">Code:</span>
                        <code className="bg-background px-2 py-1 rounded text-xs font-mono font-bold">{deal.code}</code>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground">{deal.terms}</p>
                  </CardContent>
                  <CardFooter className="mt-auto p-6">
                    <Button asChild variant="outline" className="w-full bg-transparent">
                      <Link href="/cars">View Cars</Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* No Results */}
      {filteredDeals.length === 0 && (
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <Car className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-2xl font-bold mb-2">No deals found</h3>
            <p className="text-muted-foreground mb-6">Try adjusting your filters or search query</p>
            <Button
              onClick={() => {
                setSelectedCategory("all")
                setSearchQuery("")
              }}
            >
              Clear Filters
            </Button>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Save?</h2>
          <p className="text-lg mb-8 opacity-90">Browse our fleet and apply your promo code at checkout</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="secondary">
              <Link href="/cars">Browse All Cars</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary"
            >
              <Link href="/locations">Find a Location</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
