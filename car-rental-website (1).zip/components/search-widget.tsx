"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"
import { MapPin, Calendar, Clock, Search } from "lucide-react"

export function SearchWidget() {
  const [searchData, setSearchData] = useState({
    pickupLocation: "",
    dropoffLocation: "",
    pickupDate: "",
    pickupTime: "",
    dropoffDate: "",
    dropoffTime: "",
  })

  return (
    <section className="relative -mt-16 z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <Card className="p-6 lg:p-8 shadow-2xl">
        <h2 className="text-2xl font-bold mb-6">Find Your Perfect Ride</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          <div className="space-y-2">
            <Label htmlFor="pickup-location" className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Pickup Location
            </Label>
            <Input
              id="pickup-location"
              placeholder="City, Airport, or Address"
              value={searchData.pickupLocation}
              onChange={(e) => setSearchData({ ...searchData, pickupLocation: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="pickup-date" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Pickup Date
            </Label>
            <Input
              id="pickup-date"
              type="date"
              value={searchData.pickupDate}
              onChange={(e) => setSearchData({ ...searchData, pickupDate: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="pickup-time" className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Pickup Time
            </Label>
            <Input
              id="pickup-time"
              type="time"
              value={searchData.pickupTime}
              onChange={(e) => setSearchData({ ...searchData, pickupTime: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="dropoff-location" className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Dropoff Location
            </Label>
            <Input
              id="dropoff-location"
              placeholder="Same as pickup"
              value={searchData.dropoffLocation}
              onChange={(e) => setSearchData({ ...searchData, dropoffLocation: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="dropoff-date" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Dropoff Date
            </Label>
            <Input
              id="dropoff-date"
              type="date"
              value={searchData.dropoffDate}
              onChange={(e) => setSearchData({ ...searchData, dropoffDate: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="dropoff-time" className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Dropoff Time
            </Label>
            <Input
              id="dropoff-time"
              type="time"
              value={searchData.dropoffTime}
              onChange={(e) => setSearchData({ ...searchData, dropoffTime: e.target.value })}
            />
          </div>
        </div>

        <Button size="lg" className="w-full md:w-auto bg-primary hover:bg-primary/90">
          <Search className="mr-2 h-5 w-5" />
          Search Available Cars
        </Button>
      </Card>
    </section>
  )
}
