"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Plus, Edit, Trash2, Wrench } from "lucide-react"

const fleetData = [
  {
    id: 1,
    name: "Tesla Model 3",
    category: "Electric",
    plate: "NSW-1234",
    status: "Available",
    mileage: 15420,
    nextService: "2024-03-15",
    location: "Sydney CBD",
    price: 89,
  },
  {
    id: 2,
    name: "BMW 5 Series",
    category: "Luxury",
    plate: "NSW-5678",
    status: "Rented",
    mileage: 28350,
    nextService: "2024-02-20",
    location: "Sydney Airport",
    price: 129,
  },
  {
    id: 3,
    name: "Toyota RAV4",
    category: "SUV",
    plate: "NSW-9012",
    status: "Maintenance",
    mileage: 42180,
    nextService: "2024-02-10",
    location: "Parramatta",
    price: 69,
  },
  {
    id: 4,
    name: "Mercedes-Benz C-Class",
    category: "Luxury",
    plate: "NSW-3456",
    status: "Available",
    mileage: 19200,
    nextService: "2024-03-20",
    location: "North Sydney",
    price: 139,
  },
  {
    id: 5,
    name: "Honda CR-V",
    category: "SUV",
    plate: "NSW-7890",
    status: "Available",
    mileage: 31500,
    nextService: "2024-02-25",
    location: "Bondi Beach",
    price: 75,
  },
]

export function FleetManagement() {
  const [searchTerm, setSearchTerm] = useState("")

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Available":
        return "bg-accent text-accent-foreground"
      case "Rented":
        return "bg-primary text-primary-foreground"
      case "Maintenance":
        return "bg-destructive text-destructive-foreground"
      default:
        return "bg-secondary text-secondary-foreground"
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Fleet Management</CardTitle>
          <Button className="bg-primary hover:bg-primary/90">
            <Plus className="mr-2 h-4 w-4" />
            Add Vehicle
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-6">
          <Input
            placeholder="Search by name, plate, or location..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="space-y-4">
          {fleetData.map((vehicle) => (
            <Card key={vehicle.id}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-bold mb-1">{vehicle.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      {vehicle.category} • {vehicle.plate}
                    </p>
                  </div>
                  <Badge className={getStatusColor(vehicle.status)}>{vehicle.status}</Badge>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Mileage</p>
                    <p className="font-medium">{vehicle.mileage.toLocaleString()} mi</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Next Service</p>
                    <p className="font-medium">{vehicle.nextService}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Location</p>
                    <p className="font-medium">{vehicle.location}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Daily Rate</p>
                    <p className="font-medium">${vehicle.price}</p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Edit className="mr-2 h-4 w-4" />
                    Edit
                  </Button>
                  <Button variant="outline" size="sm">
                    <Wrench className="mr-2 h-4 w-4" />
                    Service
                  </Button>
                  <Button variant="outline" size="sm" className="text-destructive bg-transparent">
                    <Trash2 className="mr-2 h-4 w-4" />
                    Remove
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
