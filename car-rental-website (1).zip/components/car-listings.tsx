"use client"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Users, Briefcase, Gauge, Star, SlidersHorizontal } from "lucide-react"
import { allCars } from "@/lib/car-data"

export function CarListings() {
  const [priceRange, setPriceRange] = useState([0, 250])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [searchTerm, setSearchTerm] = useState("")

  const categories = ["Economy", "Electric", "SUV", "Luxury", "Van", "Sports"]

  const filteredCars = allCars.filter((car) => {
    const matchesPrice = car.price >= priceRange[0] && car.price <= priceRange[1]
    const matchesCategory = selectedCategories.length === 0 || selectedCategories.includes(car.category)
    const matchesSearch = car.name.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesPrice && matchesCategory && matchesSearch
  })

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <h1 className="text-3xl lg:text-4xl font-bold mb-8">Available Vehicles</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Filters Sidebar */}
        <div className="lg:col-span-1">
          <Card className="p-6 sticky top-4">
            <div className="flex items-center gap-2 mb-6">
              <SlidersHorizontal className="h-5 w-5" />
              <h2 className="text-xl font-bold">Filters</h2>
            </div>

            <div className="space-y-6">
              <div>
                <Label htmlFor="search" className="mb-2 block">
                  Search
                </Label>
                <Input
                  id="search"
                  placeholder="Search by name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <div>
                <Label className="mb-4 block">Price Range (per day)</Label>
                <Slider value={priceRange} onValueChange={setPriceRange} max={250} step={10} className="mb-2" />
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>${priceRange[0]}</span>
                  <span>${priceRange[1]}</span>
                </div>
              </div>

              <div>
                <Label className="mb-4 block">Category</Label>
                <div className="space-y-3">
                  {categories.map((category) => (
                    <div key={category} className="flex items-center space-x-2">
                      <Checkbox
                        id={category}
                        checked={selectedCategories.includes(category)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedCategories([...selectedCategories, category])
                          } else {
                            setSelectedCategories(selectedCategories.filter((c) => c !== category))
                          }
                        }}
                      />
                      <label
                        htmlFor={category}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                      >
                        {category}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <Button
                variant="outline"
                className="w-full bg-transparent"
                onClick={() => {
                  setPriceRange([0, 250])
                  setSelectedCategories([])
                  setSearchTerm("")
                }}
              >
                Reset Filters
              </Button>
            </div>
          </Card>
        </div>

        {/* Car Grid */}
        <div className="lg:col-span-3">
          <div className="mb-4 text-muted-foreground">
            Showing {filteredCars.length} of {allCars.length} vehicles
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredCars.map((car) => (
              <Card key={car.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative">
                  <img src={car.image || "/placeholder.svg"} alt={car.name} className="w-full h-48 object-cover" />
                  <Badge className="absolute top-3 right-3 bg-background/90 text-foreground">{car.category}</Badge>
                </div>

                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-lg font-bold">{car.name}</h3>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm font-medium">{car.rating}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      <span>{car.seats}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Gauge className="h-4 w-4" />
                      <span>{car.transmission}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Briefcase className="h-4 w-4" />
                      <span>{car.luggage}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-2xl font-bold text-primary">${car.price}</span>
                      <span className="text-sm text-muted-foreground">/day</span>
                    </div>
                  </div>
                </CardContent>

                <CardFooter className="p-4 pt-0 flex gap-2">
                  <Button variant="outline" className="flex-1 bg-transparent" asChild>
                    <Link href={`/cars/${car.id}`}>Details</Link>
                  </Button>
                  <Button className="flex-1 bg-primary hover:bg-primary/90" asChild>
                    <Link href={`/cars/${car.id}`}>Book</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
