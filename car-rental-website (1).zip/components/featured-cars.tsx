"use client"

import Link from "next/link"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Users, Briefcase, Gauge, Star } from "lucide-react"

const featuredCars = [
  {
    id: 1,
    name: "Tesla Model 3",
    category: "Electric",
    image: "/tesla-model-3-sleek-profile.png",
    price: 89,
    rating: 4.9,
    reviews: 234,
    seats: 5,
    transmission: "Automatic",
    luggage: 2,
    badge: "Popular",
  },
  {
    id: 2,
    name: "BMW 5 Series",
    category: "Luxury",
    image: "/bmw-5-series.png",
    price: 129,
    rating: 4.8,
    reviews: 189,
    seats: 5,
    transmission: "Automatic",
    luggage: 3,
    badge: "Premium",
  },
  {
    id: 3,
    name: "Toyota RAV4",
    category: "SUV",
    image: "/toyota-rav4-forest.png",
    price: 69,
    rating: 4.7,
    reviews: 312,
    seats: 5,
    transmission: "Automatic",
    luggage: 4,
    badge: "Best Value",
  },
  {
    id: 4,
    name: "Mercedes-Benz S-Class",
    category: "Luxury",
    image: "/luxurious-mercedes-s-class.png",
    price: 199,
    rating: 5.0,
    reviews: 156,
    seats: 5,
    transmission: "Automatic",
    luggage: 3,
    badge: "Luxury",
  },
]

export function FeaturedCars() {
  return (
    <section className="py-16 lg:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h2 className="text-3xl lg:text-4xl font-bold mb-4">Featured Vehicles</h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Explore our handpicked selection of premium vehicles available for rent
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {featuredCars.map((car) => (
          <Card key={car.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="relative">
              <img src={car.image || "/placeholder.svg"} alt={car.name} className="w-full h-48 object-cover" />
              {car.badge && (
                <Badge className="absolute top-3 right-3 bg-accent text-accent-foreground">{car.badge}</Badge>
              )}
            </div>

            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">{car.category}</span>
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm font-medium">{car.rating}</span>
                  <span className="text-sm text-muted-foreground">({car.reviews})</span>
                </div>
              </div>

              <h3 className="text-lg font-bold mb-3">{car.name}</h3>

              <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                <div className="flex items-center gap-1">
                  <Users className="h-4 w-4" />
                  <span>{car.seats}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Gauge className="h-4 w-4" />
                  <span>{car.transmission}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Briefcase className="h-4 w-4" />
                  <span>{car.luggage}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <span className="text-2xl font-bold text-primary">${car.price}</span>
                  <span className="text-sm text-muted-foreground">/day</span>
                </div>
              </div>
            </CardContent>

            <CardFooter className="p-4 pt-0">
              <Button className="w-full bg-primary hover:bg-primary/90" asChild>
                <Link href={`/cars/${car.id}`}>Book Now</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="text-center mt-12">
        <Button variant="outline" size="lg" asChild>
          <Link href="/cars">View All Vehicles</Link>
        </Button>
      </div>
    </section>
  )
}
