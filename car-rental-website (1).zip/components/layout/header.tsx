"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Car, Menu, User } from "lucide-react"

export function Header() {
  return (
    <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2 font-bold text-xl">
            <Car className="h-6 w-6 text-primary" />
            <span>DriveNow</span>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/cars" className="text-sm font-medium hover:text-primary transition-colors">
              Browse Cars
            </Link>
            <Link href="/locations" className="text-sm font-medium hover:text-primary transition-colors">
              Locations
            </Link>
            <Link href="/deals" className="text-sm font-medium hover:text-primary transition-colors">
              Deals
            </Link>
            <Link href="/about" className="text-sm font-medium hover:text-primary transition-colors">
              About
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            <Link href="/admin" aria-label="Go to Admin Panel">
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
                <span className="sr-only">Admin Panel</span>
              </Button>
            </Link>

            {/* Keep Sign In and mobile menu */}
            <Button className="hidden md:inline-flex bg-primary hover:bg-primary/90">Sign In</Button>

            <Button variant="ghost" size="icon" className="md:hidden" aria-label="Open menu">
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}
