"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FleetManagement } from "@/components/admin/fleet-management"
import { BookingManagement } from "@/components/admin/booking-management"
import { Analytics } from "@/components/admin/analytics"
import { CustomerManagement } from "@/components/admin/customer-management"
import { Calendar, DollarSign, TrendingUp, AlertCircle } from "lucide-react"

export function AdminDashboard() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl lg:text-4xl font-bold mb-2">Admin Dashboard</h1>
        <p className="text-muted-foreground">Manage your car rental business</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total Revenue</p>
                <p className="text-3xl font-bold">$45.2K</p>
                <p className="text-sm text-accent mt-1">+12.5% from last month</p>
              </div>
              <DollarSign className="h-10 w-10 text-accent" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Active Bookings</p>
                <p className="text-3xl font-bold">28</p>
                <p className="text-sm text-primary mt-1">12 pickups today</p>
              </div>
              <Calendar className="h-10 w-10 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Fleet Utilization</p>
                <p className="text-3xl font-bold">78%</p>
                <p className="text-sm text-accent mt-1">+5% from last week</p>
              </div>
              <TrendingUp className="h-10 w-10 text-accent" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Maintenance Due</p>
                <p className="text-3xl font-bold">5</p>
                <p className="text-sm text-destructive mt-1">2 urgent</p>
              </div>
              <AlertCircle className="h-10 w-10 text-destructive" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Management Tabs */}
      <Tabs defaultValue="fleet" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 h-auto">
          <TabsTrigger value="fleet">Fleet</TabsTrigger>
          <TabsTrigger value="bookings">Bookings</TabsTrigger>
          <TabsTrigger value="customers">Customers</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="fleet" className="mt-6">
          <FleetManagement />
        </TabsContent>

        <TabsContent value="bookings" className="mt-6">
          <BookingManagement />
        </TabsContent>

        <TabsContent value="customers" className="mt-6">
          <CustomerManagement />
        </TabsContent>

        <TabsContent value="analytics" className="mt-6">
          <Analytics />
        </TabsContent>
      </Tabs>
    </div>
  )
}
