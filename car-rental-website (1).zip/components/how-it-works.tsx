"use client"

import { Search, CheckCircle, CreditCard, Key } from "lucide-react"

const steps = [
  {
    icon: Search,
    title: "Search",
    description: "Browse our extensive fleet and find the perfect car for your journey",
  },
  {
    icon: CheckCircle,
    title: "Select",
    description: "Choose your dates, location, and any additional services you need",
  },
  {
    icon: CreditCard,
    title: "Book",
    description: "Complete your reservation with our secure payment system",
  },
  {
    icon: Key,
    title: "Drive",
    description: "Pick up your car and hit the road with confidence",
  },
]

export function HowItWorks() {
  return (
    <section className="py-16 lg:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h2 className="text-3xl lg:text-4xl font-bold mb-4">How It Works</h2>
        <p className="text-lg text-muted-foreground">Rent a car in four simple steps</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {steps.map((step, index) => {
          const Icon = step.icon
          return (
            <div key={step.title} className="text-center relative">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary text-white mb-4 relative z-10">
                <Icon className="h-8 w-8" />
              </div>

              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-8 left-1/2 w-full h-0.5 bg-border -z-0" />
              )}

              <h3 className="text-xl font-bold mb-2">{step.title}</h3>
              <p className="text-muted-foreground">{step.description}</p>
            </div>
          )
        })}
      </div>
    </section>
  )
}
