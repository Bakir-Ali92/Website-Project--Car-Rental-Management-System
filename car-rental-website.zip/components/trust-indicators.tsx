"use client"

import { Shield, Award, Clock, ThumbsUp } from "lucide-react"

const indicators = [
  {
    icon: Shield,
    title: "Best Price Guarantee",
    description: "Find a better price? We'll match it",
  },
  {
    icon: Award,
    title: "Verified Cars",
    description: "All vehicles inspected and certified",
  },
  {
    icon: Clock,
    title: "24/7 Support",
    description: "We're here whenever you need us",
  },
  {
    icon: ThumbsUp,
    title: "Free Cancellation",
    description: "Cancel up to 24 hours before pickup",
  },
]

export function TrustIndicators() {
  return (
    <section className="py-16 lg:py-24 bg-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {indicators.map((indicator) => {
            const Icon = indicator.icon
            return (
              <div key={indicator.title} className="text-center">
                <Icon className="h-12 w-12 mx-auto mb-4 text-accent" />
                <h3 className="text-lg font-bold mb-2">{indicator.title}</h3>
                <p className="text-slate-300">{indicator.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
