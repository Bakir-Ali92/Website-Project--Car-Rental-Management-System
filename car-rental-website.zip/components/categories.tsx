"use client"

import { Card } from "@/components/ui/card"
import { Car, Zap, Truck, Crown, Users, Sparkles } from "lucide-react"

const categories = [
  {
    name: "Economy",
    icon: Car,
    description: "Affordable and fuel-efficient",
    startingPrice: 39,
    color: "text-blue-500",
  },
  {
    name: "Electric",
    icon: Zap,
    description: "Eco-friendly vehicles",
    startingPrice: 79,
    color: "text-green-500",
  },
  {
    name: "SUV",
    icon: Truck,
    description: "Spacious and powerful",
    startingPrice: 69,
    color: "text-orange-500",
  },
  {
    name: "Luxury",
    icon: Crown,
    description: "Premium experience",
    startingPrice: 149,
    color: "text-purple-500",
  },
  {
    name: "Van",
    icon: Users,
    description: "Perfect for groups",
    startingPrice: 89,
    color: "text-cyan-500",
  },
  {
    name: "Sports",
    icon: Sparkles,
    description: "High-performance cars",
    startingPrice: 199,
    color: "text-red-500",
  },
]

export function Categories() {
  return (
    <section className="py-16 lg:py-24 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">Browse by Category</h2>
          <p className="text-lg text-muted-foreground">Find the perfect vehicle type for your needs</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((category) => {
            const Icon = category.icon
            return (
              <Card
                key={category.name}
                className="p-6 text-center hover:shadow-lg transition-all cursor-pointer hover:-translate-y-1"
              >
                <Icon className={`h-12 w-12 mx-auto mb-3 ${category.color}`} />
                <h3 className="font-bold mb-1">{category.name}</h3>
                <p className="text-sm text-muted-foreground mb-2">{category.description}</p>
                <p className="text-sm font-medium text-primary">From ${category.startingPrice}/day</p>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
