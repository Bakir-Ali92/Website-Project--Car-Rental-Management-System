"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, DollarSign, Car, Calendar } from "lucide-react"

export function Analytics() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Revenue This Month</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-3xl font-bold">$45,231</p>
                <div className="flex items-center gap-1 text-sm text-accent mt-1">
                  <TrendingUp className="h-4 w-4" />
                  <span>+12.5% from last month</span>
                </div>
              </div>
              <DollarSign className="h-10 w-10 text-accent" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Total Bookings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-3xl font-bold">156</p>
                <div className="flex items-center gap-1 text-sm text-accent mt-1">
                  <TrendingUp className="h-4 w-4" />
                  <span>+8.2% from last month</span>
                </div>
              </div>
              <Calendar className="h-10 w-10 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Fleet Utilization</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-3xl font-bold">78%</p>
                <div className="flex items-center gap-1 text-sm text-accent mt-1">
                  <TrendingUp className="h-4 w-4" />
                  <span>+5.1% from last week</span>
                </div>
              </div>
              <Car className="h-10 w-10 text-accent" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Top Performing Vehicles</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { name: "Tesla Model 3", bookings: 45, revenue: 4005 },
              { name: "BMW 5 Series", bookings: 38, revenue: 4902 },
              { name: "Toyota RAV4", bookings: 52, revenue: 3588 },
            ].map((vehicle) => (
              <div key={vehicle.name} className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <p className="font-medium">{vehicle.name}</p>
                  <p className="text-sm text-muted-foreground">{vehicle.bookings} bookings</p>
                </div>
                <div className="text-right">
                  <p className="text-xl font-bold text-primary">${vehicle.revenue.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">revenue</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Booking Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">Weekday Bookings</span>
                <span className="font-medium">62%</span>
              </div>
              <div className="w-full bg-secondary rounded-full h-2">
                <div className="bg-primary h-2 rounded-full" style={{ width: "62%" }} />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm">Weekend Bookings</span>
                <span className="font-medium">38%</span>
              </div>
              <div className="w-full bg-secondary rounded-full h-2">
                <div className="bg-accent h-2 rounded-full" style={{ width: "38%" }} />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Customer Acquisition</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm">New Customers</span>
                <span className="text-2xl font-bold">24</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Returning Customers</span>
                <span className="text-2xl font-bold">132</span>
              </div>
              <div className="flex items-center gap-1 text-sm text-accent">
                <TrendingUp className="h-4 w-4" />
                <span>85% customer retention rate</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
