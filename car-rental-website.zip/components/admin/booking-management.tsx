"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar, User, Car, MapPin } from "lucide-react"

const bookings = [
  {
    id: "BK-001",
    customer: "Sarah Johnson",
    car: "Tesla Model 3",
    pickup: "2024-02-15 10:00",
    dropoff: "2024-02-20 10:00",
    location: "Los Angeles Airport",
    status: "Confirmed",
    total: 445,
  },
  {
    id: "BK-002",
    customer: "Michael Chen",
    car: "BMW 5 Series",
    pickup: "2024-02-16 14:00",
    dropoff: "2024-02-18 14:00",
    location: "San Francisco Downtown",
    status: "Pending",
    total: 258,
  },
  {
    id: "BK-003",
    customer: "Emily Rodriguez",
    car: "Toyota RAV4",
    pickup: "2024-02-14 09:00",
    dropoff: "2024-02-21 09:00",
    location: "Los Angeles Downtown",
    status: "Active",
    total: 483,
  },
]

export function BookingManagement() {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "Confirmed":
        return "bg-accent text-accent-foreground"
      case "Active":
        return "bg-primary text-primary-foreground"
      case "Pending":
        return "bg-yellow-500 text-white"
      default:
        return "bg-secondary text-secondary-foreground"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Booking Management</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {bookings.map((booking) => (
            <Card key={booking.id}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-bold mb-1">Booking {booking.id}</h3>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <User className="h-4 w-4" />
                      <span>{booking.customer}</span>
                    </div>
                  </div>
                  <Badge className={getStatusColor(booking.status)}>{booking.status}</Badge>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div className="flex items-center gap-2">
                    <Car className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">{booking.car}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">{booking.location}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Pickup: {booking.pickup}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Dropoff: {booking.dropoff}</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-2xl font-bold text-primary">${booking.total}</span>
                    <span className="text-sm text-muted-foreground ml-1">total</span>
                  </div>

                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                    <Button variant="outline" size="sm">
                      Modify
                    </Button>
                    <Button variant="outline" size="sm" className="text-destructive bg-transparent">
                      Cancel
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
