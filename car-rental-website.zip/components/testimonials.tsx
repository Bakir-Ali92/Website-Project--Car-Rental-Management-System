"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Star } from "lucide-react"

const testimonials = [
  {
    name: "Sarah Johnson",
    location: "New York, NY",
    rating: 5,
    comment:
      "Excellent service! The car was clean, well-maintained, and the booking process was seamless. Will definitely rent again.",
    avatar: "/professional-woman.png",
  },
  {
    name: "Michael Chen",
    location: "San Francisco, CA",
    rating: 5,
    comment:
      "Best car rental experience I've had. Great prices, friendly staff, and a wide selection of vehicles to choose from.",
    avatar: "/professional-man.png",
  },
  {
    name: "Emily Rodriguez",
    location: "Miami, FL",
    rating: 5,
    comment:
      "The 24/7 support was a lifesaver when I needed to extend my rental. Professional and accommodating service throughout.",
    avatar: "/business-woman.png",
  },
]

export function Testimonials() {
  return (
    <section className="py-16 lg:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h2 className="text-3xl lg:text-4xl font-bold mb-4">What Our Customers Say</h2>
        <p className="text-lg text-muted-foreground">Don't just take our word for it</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {testimonials.map((testimonial) => (
          <Card key={testimonial.name}>
            <CardContent className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <img
                  src={testimonial.avatar || "/placeholder.svg"}
                  alt={testimonial.name}
                  className="w-16 h-16 rounded-full object-cover"
                />
                <div>
                  <h4 className="font-bold">{testimonial.name}</h4>
                  <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                </div>
              </div>

              <div className="flex gap-1 mb-3">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>

              <p className="text-muted-foreground">{testimonial.comment}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
}
