"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MapPin, Phone, Mail, Clock, Search, Navigation, Plane, Shield, Headphones, Car } from "lucide-react"

const locations = [
  {
    id: 1,
    name: "Sydney CBD",
    address: "123 George Street, Sydney NSW 2000",
    phone: "+61 2 9000 1234",
    email: "cbd@drivenow.com.au",
    hours: "24/7",
    city: "Sydney",
    state: "NSW",
    features: ["Airport Pickup", "24/7 Service", "Premium Fleet"],
    coordinates: { lat: -33.8688, lng: 151.2093 },
    carsAvailable: 45,
  },
  {
    id: 2,
    name: "Sydney Airport",
    address: "Sydney Airport, Mascot NSW 2020",
    phone: "+61 2 9000 1235",
    email: "airport@drivenow.com.au",
    hours: "24/7",
    city: "Sydney",
    state: "NSW",
    features: ["Airport Pickup", "24/7 Service", "Express Check-in"],
    coordinates: { lat: -33.9399, lng: 151.1753 },
    carsAvailable: 78,
  },
  {
    id: 3,
    name: "Bondi Beach",
    address: "156 Campbell Parade, Bondi Beach NSW 2026",
    phone: "+61 2 9000 1236",
    email: "bondi@drivenow.com.au",
    hours: "Mon-Sun: 7:00 AM - 10:00 PM",
    city: "Sydney",
    state: "NSW",
    features: ["Convertibles", "Beach Delivery", "Luxury Cars"],
    coordinates: { lat: -33.8915, lng: 151.2767 },
    carsAvailable: 32,
  },
  {
    id: 4,
    name: "Parramatta",
    address: "45 Church Street, Parramatta NSW 2150",
    phone: "+61 2 9000 1237",
    email: "parramatta@drivenow.com.au",
    hours: "Mon-Sun: 6:00 AM - 11:00 PM",
    city: "Sydney",
    state: "NSW",
    features: ["Premium Fleet", "Corporate Packages", "Free Pickup"],
    coordinates: { lat: -33.8151, lng: 151.0001 },
    carsAvailable: 52,
  },
  {
    id: 5,
    name: "North Sydney",
    address: "89 Miller Street, North Sydney NSW 2060",
    phone: "+61 2 9000 1238",
    email: "northsydney@drivenow.com.au",
    hours: "Mon-Fri: 6:00 AM - 10:00 PM, Sat-Sun: 7:00 AM - 9:00 PM",
    city: "Sydney",
    state: "NSW",
    features: ["Business Class", "Chauffeur Service", "Premium Fleet"],
    coordinates: { lat: -33.8403, lng: 151.2065 },
    carsAvailable: 38,
  },
  {
    id: 6,
    name: "Manly",
    address: "23 The Corso, Manly NSW 2095",
    phone: "+61 2 9000 1239",
    email: "manly@drivenow.com.au",
    hours: "Mon-Sun: 7:00 AM - 9:00 PM",
    city: "Sydney",
    state: "NSW",
    features: ["Beach Delivery", "Convertibles", "SUVs Available"],
    coordinates: { lat: -33.7969, lng: 151.2873 },
    carsAvailable: 28,
  },
]

export function LocationsView() {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredLocations = locations.filter((location) => {
    const matchesSearch =
      location.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      location.address.toLowerCase().includes(searchQuery.toLowerCase())

    return matchesSearch
  })

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      {/* Hero Section */}
      <section className="bg-primary text-primary-foreground py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-balance">Find a Location in Sydney</h1>
            <p className="text-lg md:text-xl text-primary-foreground/90 mb-8 text-pretty max-w-2xl mx-auto">
              With 6 convenient locations across Sydney, we're always close by. All branches offer premium service and a
              wide selection of vehicles.
            </p>
            <div className="flex flex-wrap justify-center gap-8 text-sm">
              <div className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                <span>6 Sydney Locations</span>
              </div>
              <div className="flex items-center gap-2">
                <Plane className="h-5 w-5" />
                <span>Airport Pickup</span>
              </div>
              <div className="flex items-center gap-2">
                <Headphones className="h-5 w-5" />
                <span>24/7 Support</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                <span>Verified & Insured</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Search Section */}
      <section className="py-8 bg-background border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search by location name or address..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          <p className="text-sm text-muted-foreground mt-4">
            Showing {filteredLocations.length} location{filteredLocations.length !== 1 ? "s" : ""}
          </p>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-8 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card>
            <CardContent className="p-0">
              <div className="w-full h-96 bg-muted flex items-center justify-center rounded-lg overflow-hidden">
                <div className="text-center">
                  <MapPin className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Interactive map showing all Sydney locations</p>
                  <p className="text-sm text-muted-foreground mt-2">Map integration placeholder</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Locations Grid */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-stretch">
            {filteredLocations.map((location) => (
              <Card key={location.id} className="hover:shadow-lg transition-shadow flex flex-col">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-xl mb-2">{location.name}</CardTitle>
                      <CardDescription className="flex items-start gap-2">
                        <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                        <span>{location.address}</span>
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4 flex-1 flex flex-col">
                  {/* Contact Information */}
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2 text-sm">
                      <Phone className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                      <a href={`tel:${location.phone}`} className="hover:text-primary transition-colors">
                        {location.phone}
                      </a>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Mail className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                      <a href={`mailto:${location.email}`} className="hover:text-primary transition-colors">
                        {location.email}
                      </a>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                      <span>{location.hours}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Car className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                      <span className="font-medium">{location.carsAvailable} cars available</span>
                    </div>
                  </div>

                  {/* Features */}
                  <div className="flex flex-wrap gap-2">
                    {location.features.map((feature) => (
                      <Badge key={feature} variant="secondary" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 pt-2">
                    <Button className="flex-1" size="sm">
                      <Navigation className="h-4 w-4 mr-2" />
                      Get Directions
                    </Button>
                    <Button variant="outline" className="flex-1 bg-transparent" size="sm">
                      View Cars
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredLocations.length === 0 && (
            <div className="text-center py-12">
              <MapPin className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No locations found</h3>
              <p className="text-muted-foreground">Try adjusting your search criteria</p>
            </div>
          )}
        </div>
      </section>

      {/* Contact CTA Section */}
      <section className="py-16 bg-muted">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Need Help Finding Us?</h2>
          <p className="text-lg text-muted-foreground mb-8 text-pretty">
            Our friendly team is here to help you find the most convenient location for your needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary hover:bg-primary/90">
              <Phone className="h-5 w-5 mr-2" />
              Call Us: 1300 DRIVENOW
            </Button>
            <Button size="lg" variant="outline">
              <Mail className="h-5 w-5 mr-2" />
              Email Support
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
