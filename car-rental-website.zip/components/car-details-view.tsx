"use client"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Label } from "@/components/ui/label"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Users, Briefcase, Gauge, Star, Check, CalendarIcon, MapPin, Shield, Zap, ChevronLeft } from "lucide-react"
import { format } from "date-fns"
import type { Car } from "@/lib/car-data"
import { cn } from "@/lib/utils"

interface CarDetailsViewProps {
  car: Car
  similarCars: Car[]
}

const carReviews = [
  {
    id: 1,
    author: "Sarah Johnson",
    rating: 5,
    date: "2 weeks ago",
    comment: "Amazing car! The ride was smooth and comfortable. Highly recommend for long trips.",
  },
  {
    id: 2,
    author: "Michael Chen",
    rating: 5,
    date: "1 month ago",
    comment: "Great experience from start to finish. The car was clean and well-maintained.",
  },
  {
    id: 3,
    author: "Emily Rodriguez",
    rating: 4,
    date: "1 month ago",
    comment: "Very good car, perfect for city driving. Only minor issue was pickup time delay.",
  },
]

export function CarDetailsView({ car, similarCars }: CarDetailsViewProps) {
  const [pickupDate, setPickupDate] = useState<Date>()
  const [returnDate, setReturnDate] = useState<Date>()

  const totalDays =
    pickupDate && returnDate ? Math.ceil((returnDate.getTime() - pickupDate.getTime()) / (1000 * 60 * 60 * 24)) : 0
  const totalPrice = totalDays * car.price

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link
          href="/cars"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6"
        >
          <ChevronLeft className="h-4 w-4" />
          Back to all vehicles
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Car Image and Basic Info */}
            <Card className="overflow-hidden">
              <div className="relative">
                <img src={car.image || "/placeholder.svg"} alt={car.name} className="w-full h-96 object-cover" />
                {car.badge && (
                  <Badge className="absolute top-4 right-4 bg-accent text-accent-foreground text-base px-4 py-2">
                    {car.badge}
                  </Badge>
                )}
              </div>

              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <h1 className="text-3xl font-bold">{car.name}</h1>
                      <Badge variant="outline">{car.category}</Badge>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <span>{car.year}</span>
                      <span>•</span>
                      <span>{car.fuelType}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 mb-1">
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      <span className="text-xl font-bold">{car.rating}</span>
                    </div>
                    <span className="text-sm text-muted-foreground">({car.reviews} reviews)</span>
                  </div>
                </div>

                <p className="text-muted-foreground leading-relaxed">{car.description}</p>
              </CardContent>
            </Card>

            {/* Specifications */}
            <Card>
              <CardContent className="p-6">
                <h2 className="text-2xl font-bold mb-6">Specifications</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <div className="flex flex-col items-center text-center p-4 bg-muted/50 rounded-lg">
                    <Users className="h-8 w-8 mb-2 text-primary" />
                    <span className="text-sm text-muted-foreground mb-1">Passengers</span>
                    <span className="font-bold">{car.seats} Seats</span>
                  </div>
                  <div className="flex flex-col items-center text-center p-4 bg-muted/50 rounded-lg">
                    <Gauge className="h-8 w-8 mb-2 text-primary" />
                    <span className="text-sm text-muted-foreground mb-1">Transmission</span>
                    <span className="font-bold">{car.transmission}</span>
                  </div>
                  <div className="flex flex-col items-center text-center p-4 bg-muted/50 rounded-lg">
                    <Briefcase className="h-8 w-8 mb-2 text-primary" />
                    <span className="text-sm text-muted-foreground mb-1">Luggage</span>
                    <span className="font-bold">{car.luggage} Bags</span>
                  </div>
                  <div className="flex flex-col items-center text-center p-4 bg-muted/50 rounded-lg">
                    <Zap className="h-8 w-8 mb-2 text-primary" />
                    <span className="text-sm text-muted-foreground mb-1">Mileage</span>
                    <span className="font-bold">{car.mileage}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Features */}
            <Card>
              <CardContent className="p-6">
                <h2 className="text-2xl font-bold mb-6">Features & Amenities</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {car.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center">
                        <Check className="h-4 w-4 text-primary" />
                      </div>
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Reviews */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold">Customer Reviews</h2>
                  <Button variant="outline">Write a Review</Button>
                </div>

                <div className="space-y-6">
                  {carReviews.map((review) => (
                    <div key={review.id}>
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-bold">{review.author}</h3>
                          <span className="text-sm text-muted-foreground">{review.date}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          {Array.from({ length: review.rating }).map((_, i) => (
                            <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          ))}
                        </div>
                      </div>
                      <p className="text-muted-foreground">{review.comment}</p>
                      {review.id !== carReviews[carReviews.length - 1].id && <Separator className="mt-6" />}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Similar Cars */}
            {similarCars.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold mb-6">Similar Vehicles</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {similarCars.map((similarCar) => (
                    <Link key={similarCar.id} href={`/cars/${similarCar.id}`}>
                      <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                        <img
                          src={similarCar.image || "/placeholder.svg"}
                          alt={similarCar.name}
                          className="w-full h-40 object-cover"
                        />
                        <CardContent className="p-4">
                          <h3 className="font-bold mb-2">{similarCar.name}</h3>
                          <div className="flex items-center justify-between">
                            <span className="text-xl font-bold text-primary">${similarCar.price}/day</span>
                            <div className="flex items-center gap-1">
                              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                              <span className="text-sm">{similarCar.rating}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Booking Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardContent className="p-6">
                <div className="mb-6">
                  <div className="flex items-baseline gap-2 mb-2">
                    <span className="text-4xl font-bold text-primary">${car.price}</span>
                    <span className="text-muted-foreground">/day</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Shield className="h-4 w-4" />
                    <span>Free cancellation up to 24 hours</span>
                  </div>
                </div>

                <Separator className="my-6" />

                <div className="space-y-4">
                  <div>
                    <Label className="mb-2 block">Pickup Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !pickupDate && "text-muted-foreground",
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {pickupDate ? format(pickupDate, "PPP") : "Select date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar mode="single" selected={pickupDate} onSelect={setPickupDate} initialFocus />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div>
                    <Label className="mb-2 block">Return Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !returnDate && "text-muted-foreground",
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {returnDate ? format(returnDate, "PPP") : "Select date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar mode="single" selected={returnDate} onSelect={setReturnDate} initialFocus />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div>
                    <Label className="mb-2 block">Pickup Location</Label>
                    <Button variant="outline" className="w-full justify-start bg-transparent">
                      <MapPin className="mr-2 h-4 w-4" />
                      Select location
                    </Button>
                  </div>
                </div>

                {totalDays > 0 && (
                  <>
                    <Separator className="my-6" />
                    <div className="space-y-2 mb-6">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">
                          ${car.price} × {totalDays} days
                        </span>
                        <span>${totalPrice}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Service fee</span>
                        <span>$25</span>
                      </div>
                      <Separator />
                      <div className="flex justify-between font-bold text-lg">
                        <span>Total</span>
                        <span className="text-primary">${totalPrice + 25}</span>
                      </div>
                    </div>
                  </>
                )}

                <Button
                  className="w-full bg-primary hover:bg-primary/90"
                  size="lg"
                  disabled={!pickupDate || !returnDate}
                >
                  Book Now
                </Button>

                <div className="mt-4 space-y-2 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-primary" />
                    <span>Free cancellation</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-primary" />
                    <span>No hidden fees</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-primary" />
                    <span>24/7 customer support</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
