import { LocationsView } from "@/components/locations-view"

export const metadata = {
  title: "Our Locations - DriveNow Car Rentals",
  description:
    "Find DriveNow car rental locations near you. 50+ branches with 24/7 support and airport pickup services.",
}

export default function LocationsPage() {
  return (
    <div className="min-h-screen">
      <LocationsView />
    </div>
  )
}
