import { UserDashboard } from "@/components/user-dashboard"

export default function DashboardPage() {
  return (
    <div className="min-h-screen py-8">
      <UserDashboard />
    </div>
  )
}
